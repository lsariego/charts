/**
 * Regular Expressions for different uses
 */

// Formating number
const formatNumberRegex = /(\d)(?=(\d{3})+(?!\d))/g

export default formatNumberRegex
