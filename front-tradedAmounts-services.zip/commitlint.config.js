module.exports = {
  extends: ['jira'],
  plugins: ['commitlint-plugin-jira-rules']
}
