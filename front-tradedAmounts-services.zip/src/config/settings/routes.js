const routes = {
  home: '/',
  organization: '/organismos-compradores',
  organizationCategory: '/organismos-compradores/:category'
}

export default routes
