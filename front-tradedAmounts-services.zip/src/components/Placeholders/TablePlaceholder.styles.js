import styled from 'styled-components'

export const Root = styled.div`
  margin: ${props => props.margin};
  width: 100%;
`
