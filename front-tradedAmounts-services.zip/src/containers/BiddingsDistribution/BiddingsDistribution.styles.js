import styled from 'styled-components'
import { Container, Grid, Box } from '@material-ui/core'

export const Wrapper = styled(Container)``
export const GridWrapper = styled(Grid)``
export const BoxWrapper = styled(Box)``
