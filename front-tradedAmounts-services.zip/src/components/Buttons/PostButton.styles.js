import styled from 'styled-components'

export const Root = styled.form`
  margin: 0;
  padding: 0;
  width: 100%;
`
