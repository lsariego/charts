export const { REACT_APP_API_BASE_URL, REACT_APP_ENVIRONMENT } = process.env
export const isDevEnv = process.env.REACT_APP_ENVIRONMENT !== 'prod'
